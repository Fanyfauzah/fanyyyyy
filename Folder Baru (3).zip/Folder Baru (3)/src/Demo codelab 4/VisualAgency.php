<?php
namespace Agency;

use Agency\AgencyBase;

class VisualAgency extends AgencyBase {
    private array $designTools = [];

    public function addDesignTool(string $tool) {
        $this->designTools[] = $tool;
    }

    public function getDesignTools(): array {
        return $this->designTools;
    }

    public function renderVisual(string $project): string {
        return "Rendering visual for project: $project";
    }

    public function listVisualProjects(): string {
        return implode(", ", $this->getProjects());
    }
}