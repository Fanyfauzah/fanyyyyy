<?php
namespace Agency;

use Agency\AgencyBase;

class ConnectionAgency extends AgencyBase {
    private array $clients = [];

    public function addClient(string $client) {
        $this->clients[] = $client;
    }

    public function getClients(): array {
        return $this->clients;
    }

    public function connectClient(string $client): string {
        return "Connecting with client: $client";
    }

    public function listClientConnections(): string {
        return implode(", ", $this->clients);
    }
}