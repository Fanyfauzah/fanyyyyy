<?php
require_once 'AgencyBase.php';
require_once 'VisualAgency.php';
require_once 'ConnectionAgency.php';

use Agency\VisualAgency;
use Agency\ConnectionAgency;

// Object Operator & Magic Method
$visual = new VisualAgency("PixelCraft", "Korea selatan");
$visual->addProject("Logo Design");
$visual->addDesignTool("Photoshop");
echo $visual->renderVisual("Logo Design") . PHP_EOL;
echo $visual . PHP_EOL; 
echo $visual->location . PHP_EOL; // public property

$connection = new ConnectionAgency("NetBridge", "Soul");
$connection->addClient("PT. MekarJaya");
$connection->addProject("Client Onboarding");
echo $connection->connectClient("PT. YG") . PHP_EOL;
echo $connection->listClientConnections() . PHP_EOL;
echo $connection->getAgencyName() . PHP_EOL;