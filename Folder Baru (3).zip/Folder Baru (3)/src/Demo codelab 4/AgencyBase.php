<?php
namespace Agency;

class AgencyBase {
    // Access modifiers
    protected string $agencyName;
    private array $projects = [];
    public string $location;

    public function __construct(string $name, string $location) {
        $this->agencyName = $name;
        $this->location = $location;
    }

    public function addProject(string $project) {
        $this->projects[] = $project;
    }

    public function getProjects(): array {
        return $this->projects;
    }

    public function getAgencyName(): string {
        return $this->agencyName;
    }

    // Magic method
    public function __get($property) {
        return $this->$property ?? "Property not accessible";
    }

    // Magic method
    public function __toString(): string {
        return "Agency: {$this->agencyName}, Location: {$this->location}";
    }
}