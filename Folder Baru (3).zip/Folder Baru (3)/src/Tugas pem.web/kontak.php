<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nama = htmlspecialchars($_POST["nama"]);
  $email = htmlspecialchars($_POST["email"]);
  $pesan = htmlspecialchars($_POST["pesan"]);
 echo "<div style='max-width:500px;margin:40px auto;padding:20px;background:#f0f0f0;border-radius:10px;text-align:center;'>
<h2>Terima kasih, $nama!</h2>
<p>Pesan Anda telah dikirim.</p>
</div>";
}
?>

