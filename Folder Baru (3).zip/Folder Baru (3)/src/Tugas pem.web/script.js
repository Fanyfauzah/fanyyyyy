// Toggle Visi Misi di index.html
$(document).ready(function () {
  $("#toggleVisi").click(function () {
    $("#visiMisi").slideToggle("slow");
  });
});

// Filter Galeri Artis di artis.html
$(document).ready(function () {
  $(".filter button").click(function () {
    const group = $(this).data("group");
    $("#gallery .card").each(function () {
      const cardGroup = $(this).data("group");
      if (group === "all" || group === cardGroup) {
        $(this).fadeIn();
      } else {
        $(this).fadeOut();
      }
    });
  });
});

// Validasi Form Kontak di kontak.php
function validateForm() {
  const nama = document.getElementById("nama").value.trim();
  const email = document.getElementById("email").value.trim();
  const pesan = document.getElementById("pesan").value.trim();

  if (!nama || !email || !pesan) {
    alert("Semua field wajib diisi!");
    return false;
  }

  const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
  if (!email.match(emailPattern)) {
    alert("Format email tidak valid!");
    return false;
  }

  return true;
}

