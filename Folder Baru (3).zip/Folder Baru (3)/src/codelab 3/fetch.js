async function ambilBuku(query = 'javascript') {
  const endpoint = `https://www.googleapis.com/books/v1/volumes?q=javascript&maxResults=40`;

  try {
    const $container = $('#hasil, #buku-container');
    $container.html('<p class="text-gray-600">Memuat data buku...</p>');

    const response = await fetch(endpoint);

    if (!response.ok) {
      throw new Error(`HTTP error ${response.status}`);
    }

    const data = await response.json();

    // buat Validasi hasil
    if (!data || !data.items || data.items.length === 0) {
      $container.html('<p class="text-red-600 font-semibold">Tidak ada hasil ditemukan.</p>');
      return;
    }

    const hasilHTML = data.items.map(item => {
      const info = item.volumeInfo;
      const thumbnail = info.imageLinks?.thumbnail || info.imageLinks?.smallThumbnail || 'https://via.placeholder.com/128x198?text=No+Cover';
      const title = info.title || 'Judul tidak tersedia';
      const authors = info.authors?.join(', ') || 'Tidak diketahui';
      const previewLink = info.previewLink || '#';
      return `
        <div class="card bg-white rounded overflow-hidden shadow-lg">
          <img class="w-full h-48 object-contain bg-gray-100" src="${thumbnail}" alt="Cover Buku untuk ${title}">
          <div class="px-6 py-4">
            <div class="font-bold text-lg mb-2">${title}</div>
            <p class="text-gray-700 text-sm">${authors}</p>
          </div>
          <div class="px-6 pt-4 pb-6">
            <a href="${previewLink}" target="_blank" rel="noopener noreferrer" class="inline-block bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition-all transform hover:-translate-y-1">
              Lihat Buku
            </a>
          </div>
        </div>
      `;
    }).join('');

  const gridHTML = `<div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">${hasilHTML}</div>`;
  $container.html(gridHTML);

  } catch (error) {
    console.error('Gagal fetch data:', error);
    $container.html('<p class="text-red-600 font-semibold">❌ Gagal memuat data buku. Periksa koneksi atau coba lagi nanti.</p>');
  }
}

// Jalankan saat halaman dimuat
$(document).ready(function () {
  ambilBuku();
});