const apiUrl = 'https://pokeapi.co/api/v2/pokemon?limit=12';//API

fetch(apiUrl)
  .then(response => response.json())//Mengubah respons menjadi format JSON agar bisa diolah
  .then(data => {
    const pokemonList = document.getElementById('pokemon-list');
    const loading = document.getElementById('loading');
    loading.style.display = 'none';

    data.results.forEach(pokemon => {
      fetch(pokemon.url)//fetch kedua untuk mendapatkan gambar dan tipe Pokémon

        .then(response => response.json())
        .then(detail => {
          const card = document.createElement('div');//Membuat elemen div sebagai kartu visual untuk tiap Pokémon
          card.style.width = '200px'; 
          card.style.margin = '10px';
          card.style.padding = '10px';
          card.style.borderRadius = '8px';
          card.style.background = '#fff';
          card.style.boxShadow = '0 4px 8px rgba(0,0,0,0.1)';
          card.style.textAlign = 'center';

          const img = document.createElement('img');//Menampilkan gambar Pokémon dari API
          img.src = detail.sprites.front_default;
          img.alt = detail.name;
          img.style.width = '100px';
          img.style.marginBottom = '10px';

          const name = document.createElement('h4');//nama dan tipe pokemon
          name.textContent = detail.name;

          const type = document.createElement('p');//Tipe bisa lebih dari satu, jadi pakai .map() dan .join(', ').
          type.textContent = 'Type: ' + detail.types.map(t => t.type.name).join(', ');
          type.style.color = '#555';
          //Menyusun elemen gambar, nama, dan tipe ke dalam kartu dan menambahkan kartu ke dalam #pokemon-list
          card.appendChild(img);
          card.appendChild(name);
          card.appendChild(type);
          pokemonList.appendChild(card);
        });
    });
  })
  .catch(error => {
    console.error('Gagal fetch:', error);
    document.getElementById('loading').innerText = 'Gagal memuat data.';
  });