<?php

namespace App\Service;

use App\Entity\Product;
use App\Entity\DigitalProduct;

/**
 * Class ProductManager - Service untuk mengelola products
 */
class ProductManager
{
    private array $products = [];

    /**
     * Menambah product ke dalam list
     */
    public function addProduct(Product $product): void
    {
        $this->products[] = $product;
    }

    /**
     * Mendapatkan semua products
     */
    public function getAllProducts(): array
    {
        return $this->products;
    }

    /**
     * Mencari product berdasarkan nama
     */
    public function findByName(string $name): ?Product
    {
        foreach ($this->products as $product) {
            if ($product->getName() === $name) {
                return $product;
            }
        }
        return null;
    }

    /**
     * Menampilkan semua products
     */
    public function displayAll(): void
    {
        echo "=== DAFTAR PRODUK ===\n\n";
        foreach ($this->products as $index => $product) {
            // Menggunakan object operator (->)
            echo ($index + 1) . ". " . $product . "\n";
        }
        echo "\n";
    }

    /**
     * Magic Method __call
     * Dipanggil saat method yang tidak ada dipanggil
     */
    public function __call($method, $arguments)
    {
        echo "Method '{$method}' tidak ditemukan dalam class " . get_class($this) . "\n";
    }

    /**
     * Magic Method __invoke
     * Membuat object bisa dipanggil seperti function
     */
    public function __invoke(): int
    {
        return count($this->products);
    }
}
