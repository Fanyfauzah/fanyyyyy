<?php

namespace App\Entity;

/**
 * Class Product - Contoh penerapan OOP
 * Menerapkan: Class, Method, Access Modifier, Magic Methods
 */
class Product
{
    // Properties dengan access modifier berbeda
    private string $name;
    protected float $price;
    public string $category;
    private int $stock;

    /**
     * Constructor - Magic Method __construct
     */
    public function __construct(string $name, float $price, string $category, int $stock = 0)
    {
        $this->name = $name;
        $this->price = $price;
        $this->category = $category;
        $this->stock = $stock;
    }

    /**
     * Getter untuk name
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * Setter untuk name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * Getter untuk price
     */
    public function getPrice(): float
    {
        return $this->price;
    }

    /**
     * Setter untuk price
     */
    public function setPrice(float $price): void
    {
        if ($price < 0) {
            throw new \Exception("Harga tidak boleh negatif");
        }
        $this->price = $price;
    }

    /**
     * Getter untuk stock
     */
    public function getStock(): int
    {
        return $this->stock;
    }

    /**
     * Method untuk menambah stock
     */
    public function addStock(int $quantity): void
    {
        $this->stock += $quantity;
    }

    /**
     * Method untuk mengurangi stock
     */
    public function reduceStock(int $quantity): bool
    {
        if ($this->stock >= $quantity) {
            $this->stock -= $quantity;
            return true;
        }
        return false;
    }

    /**
     * Magic Method __toString
     * Dipanggil otomatis saat object di-echo
     */
    public function __toString(): string
    {
        return sprintf(
            "Produk: %s | Kategori: %s | Harga: Rp %s | Stock: %d",
            $this->name,
            $this->category,
            number_format($this->price, 0, ',', '.'),
            $this->stock
        );
    }

    /**
     * Magic Method __get
     * Dipanggil saat mengakses property yang tidak accessible
     */
    public function __get($property)
    {
        if (property_exists($this, $property)) {
            return $this->$property;
        }
        return null;
    }

    /**
     * Magic Method __set
     * Dipanggil saat set property yang tidak accessible
     */
    public function __set($property, $value)
    {
        if (property_exists($this, $property)) {
            $this->$property = $value;
        }
    }

    /**
     * Magic Method __isset
     * Dipanggil saat menggunakan isset() atau empty()
     */
    public function __isset($property): bool
    {
        return isset($this->$property);
    }
}
