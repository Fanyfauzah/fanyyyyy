<?php

namespace App\Entity;

// Menggunakan 'use' untuk namespace
use App\Entity\Product;

/**
 * Class DigitalProduct - Contoh Inheritance
 * Mewarisi dari class Product
 */
class DigitalProduct extends Product
{
    private string $downloadLink;
    private int $downloadLimit;

    /**
     * Constructor dengan parent constructor
     */
    public function __construct(
        string $name, 
        float $price, 
        string $category, 
        string $downloadLink,
        int $downloadLimit = 3
    ) {
        // Memanggil parent constructor
        parent::__construct($name, $price, $category, 999); 
        $this->downloadLink = $downloadLink;
        $this->downloadLimit = $downloadLimit;
    }

    /**
     * Getter untuk downloadLink
     */
    public function getDownloadLink(): string
    {
        return $this->downloadLink;
    }

    /**
     * Method khusus untuk digital product
     */
    public function getDownloadInfo(): string
    {
        return "Link Download: {$this->downloadLink} (Limit: {$this->downloadLimit}x)";
    }

    /**
     * Override method dari parent
     * Menambahkan informasi tambahan untuk digital product
     */
    public function __toString(): string
    {
        // Mengakses protected property dari parent
        return sprintf(
            "Produk Digital: %s | Kategori: %s | Harga: Rp %s | %s",
            $this->getName(),
            $this->category,
            number_format($this->price, 0, ',', '.'),
            $this->getDownloadInfo()
        );
    }

    /**
     * Magic Method __clone
     * Dipanggil saat object di-clone
     */
    public function __clone()
    {
        // Reset download link saat di-clone
        $this->downloadLink = "cloned-" . $this->downloadLink;
    }
}
