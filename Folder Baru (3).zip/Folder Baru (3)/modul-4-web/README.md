# Codelab Modul 4 Pemrograman Web
## Konsep yang Diterapkan

### 1. **Class & Object**

- `Product` - Class untuk produk fisik
- `DigitalProduct` - Class untuk produk digital
- `ProductManager` - Service class untuk mengelola produk

### 2. **Namespace & Use**

- `namespace App\Entity` - Untuk entity classes
- `namespace App\Service` - Untuk service classes
- `use` statement untuk import classes

### 3. **Access Modifier**

- `private` - property: name, price, stock, downloadLink, downloadLimit
- `protected` - property: price (accessible dari child class)
- `public` - property: category, methods

### 4. **Method**

- Constructor
- Getter & Setter
- Business logic methods (addStock, reduceStock, dll)

### 5. **Object Operator (->)**

- Mengakses properties: `$laptop->category`
- Memanggil methods: `$laptop->getName()`

### 6. **Inheritance**

- `DigitalProduct extends Product`
- Override method `__toString()`
- Menggunakan `parent::__construct()`

### 7. **Magic Methods**

- `__construct()` - Constructor
- `__toString()` - Konversi object ke string
- `__get()` - Akses property yang tidak accessible
- `__set()` - Set property yang tidak accessible
- `__isset()` - Check property dengan isset()
- `__clone()` - Behavior saat object di-clone
- `__call()` - Handle method yang tidak ada
- `__invoke()` - Object sebagai function

## Cara Menjalankan

```bash
php index.php
```

## Struktur File

```
codelab4/
├── src/
│   ├── Entity/
│   │   ├── Product.php
│   │   └── DigitalProduct.php
│   └── Service/
│       └── ProductManager.php
├── index.php
└── README.md
```

## Output Program

Program akan menampilkan demonstrasi semua konsep OOP yang diterapkan, termasuk:

- Pembuatan object
- Penggunaan inheritance
- Demonstrasi magic methods
- Pengelolaan produk dengan service class
