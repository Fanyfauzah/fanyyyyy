<?php

// Native includes (tanpa autoload/composer)
require_once __DIR__ . '/App/Entity/Product.php';
require_once __DIR__ . '/App/Entity/DigitalProduct.php';
require_once __DIR__ . '/App/Service/ProductManager.php';


// Menggunakan namespace dengan 'use'
use App\Entity\Product;
use App\Entity\DigitalProduct;
use App\Service\ProductManager;

echo "=== CODELAB MODUL 4 WEB ===\n\n";

// 1. Membuat object Product
echo "1. Membuat Product:\n";
$laptop = new Product("Laptop Gaming", 15000000, "Electronics", 5);
echo "   " . $laptop . "\n\n";

// 2. Menggunakan method
echo "2. Menggunakan Method:\n";
echo "   Nama: " . $laptop->getName() . "\n";
echo "   Harga: Rp " . number_format($laptop->getPrice(), 0, ',', '.') . "\n";
echo "   Stock: " . $laptop->getStock() . "\n\n";

// 3. Inheritance - DigitalProduct
echo "3. Inheritance (DigitalProduct extends Product):\n";
$ebook = new DigitalProduct("Ebook PHP OOP Modul 4 Website", 99000, "Digital", "https://example.com/ebook");
echo "   " . $ebook . "\n\n";

// 4. ProductManager
echo "4. ProductManager:\n";
$manager = new ProductManager();
$manager->addProduct($laptop);
$manager->addProduct($ebook);
$manager->addProduct(new Product("Mouse", 150000, "Electronics", 10));
$manager->displayAll();

echo "Total produk: " . $manager() . "\n";
