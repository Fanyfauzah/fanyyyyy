// kalkulator.js

// Import modul 'readline' untuk interaksi I/O di Node.js
const readline = require('readline');

// Check for interactive terminal. If not interactive (e.g. Debug Console), print a helpful message and exit.
if (!process.stdin.isTTY || !process.stdout.isTTY) {
  console.error('Non-interactive terminal detected. Please run this script in an interactive terminal (e.g. PowerShell, Command Prompt, or VS Code Integrated Terminal) without the debugger attached.');
  console.error("Try: node 'src\\code lab 2\\kalkulator.js'");
  process.exit(1);
}

// Membuat interface readline
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});


// Array untuk menyimpan data mahasiswa (Nama dan Nilai)
const students = [];

// Fungsi untuk menambahkan data mahasiswa baru ke array
// Menggunakan object destructuring untuk parameter
const addStudent = ({ name, grades }) => {
  // Menghitung rata-rata nilai
  const avg = calcAvg(grades);

  // Membuat object student baru
  const newStudent = {
    name: name,
    grades: grades,
    avg: avg
  };

  // Menambahkan student ke array students
  students.push(newStudent);
  
  // Menampilkan hasil setelah data ditambahkan
  displayResult(newStudent);
};

// Fungsi untuk menghitung rata-rata nilai
const calcAvg = (grades) => {
  // Menggunakan Array.prototype.reduce untuk menjumlahkan semua nilai
  const sum = grades.reduce((accumulator, currentValue) => accumulator + currentValue, 0);
  // Menghitung rata-rata
  return sum / grades.length;
};

// Fungsi untuk menampilkan hasil satu mahasiswa
const displayResult = (student) => {
  const { name, grades, avg } = student;
  
console.log('-----------------------------------------');
  console.log(`Input Nama: ${name}`);
  console.log(`Input Nilai: ${grades.join(', ')}`);
  console.log(`Rata-Rata Nilai: ${avg.toFixed(2)}`);

  if (avg >= 60) {
    console.log('Status: Lulus! 🎉');
  } else {
    console.log('Status: Belajar lagi! 📚');
  }
  console.log('-----------------------------------------');
};

// Fungsi utama yang menjalankan proses interaksi
const runCalculator = () => {
  // 1. Meminta input Nama Mahasiswa
  rl.question('Input nama mahasiswa? (Ketik \'EXIT\' untuk selesai) : ', (name) => {
    // Trim and validate name
    const trimmedName = String(name || '').trim();
    if (trimmedName.toUpperCase() === 'EXIT') {
      console.log('\n===== HASIL AKHIR MAHASISWA =====');
      
      // Jika ada data mahasiswa, tampilkan dalam bentuk tabel
      if (students.length > 0) {
        // Menggunakan console.table untuk tampilan yang rapi
        console.table(students.map(student => ({
          'Nama': student.name,
          'Nilai': student.grades.join(', '),
          'Rata-Rata': student.avg.toFixed(2),
          'Status': student.avg >= 60 ? 'Lulus' : 'Gagal'
        })));
      } else {
        console.log('Tidak ada data mahasiswa yang dimasukkan.');
      }
      
      rl.close();
      return;
    }

    // If name is empty, prompt again
    if (trimmedName === '') {
      console.log('⚠ Nama tidak boleh kosong. Silakan coba lagi.');
      runCalculator();
      return;
    }

    // 2. Meminta input Nilai
    // Nilai dipisahkan koma, cth: 80,90,70
    rl.question('Input nilai (pisahkan dengan koma, cth: 80,90,70) : ', (inputGrades) => {
      
      // Proses nilai input:
      // a. Pisahkan string berdasarkan koma menjadi array string
      // b. Map array string ke array angka (menggunakan Number)
      const rawParts = String(inputGrades || '').split(',');
      const grades = rawParts
        .map(grade => Number(grade.trim()))
        .filter(grade => !isNaN(grade) && grade >= 0 && grade <= 100); // Filter untuk nilai valid

      const invalidCount = rawParts.length - grades.length;
      if (invalidCount > 0) {
        console.log(`⚠ ${invalidCount} nilai diabaikan karena tidak valid (harus 0-100).`);
      }

      // Validasi input
      if (grades.length === 0) {
        console.log('⚠ Input nilai tidak valid atau kosong. Harap masukkan minimal satu nilai yang benar (0-100).');
        // Panggil kembali fungsi runCalculator untuk mengulang input nama
        runCalculator(); 
        return;
      }

  // 3. Tambahkan data mahasiswa (gunakan trimmed name)
  addStudent({ name: trimmedName, grades: grades });
      
      // 4. Ulangi proses
      runCalculator();
    });
  });
};

// Panggil fungsi utama untuk memulai aplikasi
console.log('🚀 Kalkulator Rata-Rata Nilai Mahasiswa (Node.js ES6)');
console.log('----------------------------------------------------');
runCalculator();